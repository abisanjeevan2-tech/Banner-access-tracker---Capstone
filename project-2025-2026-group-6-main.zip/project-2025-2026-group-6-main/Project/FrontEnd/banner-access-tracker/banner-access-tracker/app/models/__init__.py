from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, DateTime, Boolean, Text, 
    ForeignKey, Table, JSON, UniqueConstraint
)
from sqlalchemy.orm import relationship
from app.database import Base


# Association tables for many-to-many relationships
access_request_forms = Table(
    'access_request_forms',
    Base.metadata,
    Column('access_request_id', Integer, ForeignKey('access_requests.id', ondelete='CASCADE')),
    Column('form_id', Integer, ForeignKey('forms.id', ondelete='CASCADE'))
)

access_request_permission_groups = Table(
    'access_request_permission_groups',
    Base.metadata,
    Column('access_request_id', Integer, ForeignKey('access_requests.id', ondelete='CASCADE')),
    Column('permission_group_id', Integer, ForeignKey('permission_groups.id', ondelete='CASCADE'))
)

grantor_forms = Table(
    'grantor_forms',
    Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id', ondelete='CASCADE')),
    Column('form_id', Integer, ForeignKey('forms.id', ondelete='CASCADE'))
)


class Role(Base):
    __tablename__ = "roles"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, nullable=False, index=True)
    
    users = relationship("User", back_populates="role")


class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    cwid = Column(String(20), unique=True, nullable=False, index=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    email = Column(String(255), nullable=True)
    role_id = Column(Integer, ForeignKey("roles.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    role = relationship("Role", back_populates="users")
    submitted_requests = relationship("AccessRequest", foreign_keys="AccessRequest.submitted_by_user_id", back_populates="submitted_by")
    applicant_requests = relationship("AccessRequest", foreign_keys="AccessRequest.applicant_user_id", back_populates="applicant")
    approvals = relationship("Approval", back_populates="grantor")
    audit_logs = relationship("AuditLog", back_populates="actor")
    requested_changes = relationship("AccessChange", back_populates="requested_by")
    approved_forms = relationship("Form", secondary="grantor_forms", back_populates="authorized_grantors")

class Form(Base):
    __tablename__ = "forms"

    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    access_requests = relationship("AccessRequest", secondary=access_request_forms, back_populates="forms")
    pdf = relationship("FormPDF", back_populates="form", uselist=False)
    authorized_grantors = relationship("User", secondary="grantor_forms", back_populates="approved_forms")

class PermissionGroup(Base):
    __tablename__ = "permission_groups"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    access_requests = relationship("AccessRequest", secondary=access_request_permission_groups, back_populates="permission_groups")


class AccessRequest(Base):
    __tablename__ = "access_requests"
    
    id = Column(Integer, primary_key=True, index=True)
    applicant_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    submitted_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    status = Column(String(50), nullable=False, default="Pending", index=True)
    secure_notes_encrypted = Column(Text)  # Encrypted with Fernet
    access_type = Column(String(20), nullable=False, default="Read")  # 'Read' or 'Read/Write'
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    applicant = relationship("User", foreign_keys=[applicant_user_id], back_populates="applicant_requests")
    submitted_by = relationship("User", foreign_keys=[submitted_by_user_id], back_populates="submitted_requests")
    forms = relationship("Form", secondary=access_request_forms, back_populates="access_requests")
    permission_groups = relationship("PermissionGroup", secondary=access_request_permission_groups, back_populates="access_requests")
    approvals = relationship("Approval", back_populates="access_request", cascade="all, delete-orphan")
    attachments = relationship("Attachment", back_populates="access_request", cascade="all, delete-orphan")
    access_changes = relationship("AccessChange", back_populates="original_request")


class Approval(Base):
    __tablename__ = "approvals"

    id = Column(Integer, primary_key=True, index=True)
    access_request_id = Column(Integer, ForeignKey("access_requests.id", ondelete="CASCADE"), nullable=False)
    grantor_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    form_id = Column(Integer, ForeignKey("forms.id", ondelete="SET NULL"), nullable=True)
    decision = Column(String(20), nullable=False)  # 'approved' or 'denied'
    comment = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    access_request = relationship("AccessRequest", back_populates="approvals")
    grantor = relationship("User", back_populates="approvals")
    form = relationship("Form")


class Attachment(Base):
    __tablename__ = "attachments"
    
    id = Column(Integer, primary_key=True, index=True)
    access_request_id = Column(Integer, ForeignKey("access_requests.id", ondelete="CASCADE"), nullable=False)
    filename = Column(String(255), nullable=False)
    content_type = Column(String(100))
    storage_path = Column(String(500), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    access_request = relationship("AccessRequest", back_populates="attachments")


class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    actor_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100), nullable=False, index=True)
    entity_type = Column(String(50))
    entity_id = Column(Integer)
    metadata_json = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    actor = relationship("User", back_populates="audit_logs")


class SystemSetting(Base):
    __tablename__ = "system_settings"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(100), unique=True, nullable=False, index=True)
    value = Column(Text)
    description = Column(Text)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AccessChange(Base):
    __tablename__ = "access_changes"

    id = Column(Integer, primary_key=True, index=True)
    original_access_request_id = Column(Integer, ForeignKey("access_requests.id"), nullable=False)
    requested_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    change_type = Column(String(50), nullable=False)
    reason = Column(Text)
    status = Column(String(50), default="Pending")
    created_at = Column(DateTime, default=datetime.utcnow)

    original_request = relationship("AccessRequest", back_populates="access_changes")
    requested_by = relationship("User", back_populates="requested_changes")


class FormPDF(Base):
    __tablename__ = "form_pdfs"

    id = Column(Integer, primary_key=True, index=True)
    form_id = Column(Integer, ForeignKey("forms.id", ondelete="CASCADE"), nullable=False, unique=True)
    filename = Column(String(255), nullable=False)
    content_type = Column(String(100), default="application/pdf")
    file_data = Column(Text, nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    form = relationship("Form", back_populates="pdf")
