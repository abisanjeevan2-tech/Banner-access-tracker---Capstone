from fastapi import APIRouter, Request, Response, Depends, Form, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User, Role
from app.utils.auth import verify_password, create_session_token, verify_session_token
from app.utils.audit import audit_logger
from app.config import settings
from typing import Optional

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def get_current_user(request: Request, db: Session = Depends(get_db)) -> Optional[User]:
    """Get current logged-in user from session cookie"""
    token = request.cookies.get(settings.SESSION_COOKIE_NAME)
    if not token:
        return None
    
    user_id = verify_session_token(token)
    if not user_id:
        return None
    
    user = db.query(User).filter(User.id == user_id).first()
    return user


def require_auth(request: Request, db: Session = Depends(get_db)) -> User:
    """Dependency to require authentication"""
    user = get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


def require_role(allowed_roles: list):
    """Dependency factory to require specific roles"""
    def role_checker(user: User = Depends(require_auth)) -> User:
        if user.role.name not in allowed_roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return role_checker


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Display login page"""
    return templates.TemplateResponse("login.html", {"request": request})


@router.post("/login")
async def login(
    request: Request,
    response: Response,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    """Process login"""
    user = db.query(User).filter(User.username == username).first()
    
    if not user or not verify_password(password, user.password_hash):
        audit_logger.log_login(db, None, username, False)
        return templates.TemplateResponse(
            "login.html",
            {"request": request, "error": "Invalid username or password"},
            status_code=401
        )
    
    # Create session
    token = create_session_token(user.id)
    
    # Log successful login
    audit_logger.log_login(db, user.id, username, True)
    
    # Redirect based on role
    redirect_url = "/dashboard"
    
    response = RedirectResponse(url=redirect_url, status_code=303)
    response.set_cookie(
        key=settings.SESSION_COOKIE_NAME,
        value=token,
        max_age=settings.SESSION_MAX_AGE,
        httponly=True,
        samesite="lax"
    )
    
    return response


@router.get("/logout")
async def logout(response: Response):
    """Logout user"""
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie(settings.SESSION_COOKIE_NAME)
    return response


@router.get("/dashboard")
async def dashboard(
    request: Request,
    user: User = Depends(require_auth),
    db: Session = Depends(get_db)
):
    """Redirect to role-specific dashboard"""
    role_name = user.role.name
    
    if role_name == settings.ROLE_GRANTEE:
        return RedirectResponse(url="/grantee/dashboard")
    elif role_name == settings.ROLE_GRANTOR:
        return RedirectResponse(url="/grantor/dashboard")
    elif role_name == settings.ROLE_ADMIN:
        return RedirectResponse(url="/admin/dashboard")
    elif role_name == settings.ROLE_SUPERUSER:
        return RedirectResponse(url="/superuser/dashboard")
    else:
        return RedirectResponse(url="/login")
